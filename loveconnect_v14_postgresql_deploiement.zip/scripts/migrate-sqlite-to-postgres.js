import { DatabaseSync } from 'node:sqlite';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL est obligatoire.');
const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const sqlitePath = path.join(__dirname, '..', 'data', 'loveconnect.sqlite');
if (!existsSync(sqlitePath)) throw new Error(`Base SQLite introuvable: ${sqlitePath}`);

const sqlite = new DatabaseSync(sqlitePath, { readOnly: true });
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false });

await pool.query(`
  CREATE TABLE IF NOT EXISTS users (id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TIMESTAMPTZ NOT NULL, updated_at TIMESTAMPTZ NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions (id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, token_hash TEXT NOT NULL UNIQUE, expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL);
  CREATE TABLE IF NOT EXISTS posts (id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL);
`);

const client = await pool.connect();
try {
  await client.query('BEGIN');
  const users = sqlite.prepare('SELECT id,name,email,password_hash,role,created_at,updated_at FROM users ORDER BY id').all();
  for (const u of users) await client.query(`INSERT INTO users(id,name,email,password_hash,role,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (id) DO NOTHING`, [u.id,u.name,u.email,u.password_hash,u.role,u.created_at,u.updated_at]);
  const sessions = sqlite.prepare('SELECT id,user_id,token_hash,expires_at,created_at FROM sessions ORDER BY id').all();
  for (const s of sessions) await client.query(`INSERT INTO sessions(id,user_id,token_hash,expires_at,created_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT (id) DO NOTHING`, [s.id,s.user_id,s.token_hash,s.expires_at,s.created_at]);
  const posts = sqlite.prepare('SELECT id,user_id,body,created_at FROM posts ORDER BY id').all();
  for (const p of posts) await client.query(`INSERT INTO posts(id,user_id,body,created_at) VALUES($1,$2,$3,$4) ON CONFLICT (id) DO NOTHING`, [p.id,p.user_id,p.body,p.created_at]);
  await client.query(`SELECT setval(pg_get_serial_sequence('users','id'), COALESCE((SELECT MAX(id) FROM users),1), true); SELECT setval(pg_get_serial_sequence('sessions','id'), COALESCE((SELECT MAX(id) FROM sessions),1), true); SELECT setval(pg_get_serial_sequence('posts','id'), COALESCE((SELECT MAX(id) FROM posts),1), true);`);
  await client.query('COMMIT');
  console.log(`Migration terminée: ${users.length} utilisateurs, ${sessions.length} sessions, ${posts.length} publications.`);
} catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); sqlite.close(); await pool.end(); }
