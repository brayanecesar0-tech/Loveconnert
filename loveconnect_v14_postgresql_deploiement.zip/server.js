import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const IS_PROD = process.env.NODE_ENV === 'production';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL est obligatoire.');
if (IS_PROD && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET === 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET')) throw new Error('SESSION_SECRET est obligatoire et doit être changé en production.');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: IS_PROD ? { rejectUnauthorized: false } : false,
  max: Number(process.env.DB_POOL_MAX || 5),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      created_at TIMESTAMPTZ NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
    CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
    CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_posts_user ON posts(user_id);
  `);
}
await initDb();

const COOKIE = 'lc_session';
const SESSION_DAYS = 14;
const now = () => new Date().toISOString();
const json = (res, status, data, extra={}) => { const body=JSON.stringify(data); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store', ...extra}); res.end(body); };
const hashToken = t => crypto.createHash('sha256').update(t).digest('hex');
function passwordHash(password, salt=crypto.randomBytes(16).toString('hex')) { const key=crypto.scryptSync(password, salt, 64); return `scrypt$${salt}$${key.toString('hex')}`; }
function passwordOk(password, stored) { const [,salt,hex]=stored.split('$'); if(!salt||!hex)return false; const a=crypto.scryptSync(password,salt,64), b=Buffer.from(hex,'hex'); return a.length===b.length && crypto.timingSafeEqual(a,b); }
function cookie(name,value,maxAge){ return `${name}=${value}; Max-Age=${maxAge}; Path=/; HttpOnly; SameSite=Lax${IS_PROD?'; Secure':''}`; }
function parseCookies(req){ const out={}; for(const p of (req.headers.cookie||'').split(';')){const i=p.indexOf('='); if(i>0)out[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim());} return out; }
async function userFromReq(req){ const token=parseCookies(req)[COOKIE]; if(!token)return null; const { rows }=await pool.query(`SELECT u.id,u.name,u.email,u.role,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1`,[hashToken(token)]); const row=rows[0]; if(!row)return null; if(new Date(row.expires_at)<=new Date()){await pool.query('DELETE FROM sessions WHERE token_hash=$1',[hashToken(token)]);return null;} return row; }
async function body(req){ let s=''; for await(const c of req)s+=c; if(s.length>1_000_000)throw Error('PAYLOAD_TOO_LARGE'); return s?JSON.parse(s):{}; }
function sameOrigin(req){ const origin=req.headers.origin; if(!origin)return true; const proto=(IS_PROD||TRUST_PROXY)?'https':'http'; return origin===`${proto}://${req.headers.host}`; }
const rateBuckets = new Map();
function rateLimit(key, limit=20, windowMs=60_000){ const t=Date.now(); const b=rateBuckets.get(key)||{start:t,count:0}; if(t-b.start>=windowMs){b.start=t;b.count=0;} b.count++; rateBuckets.set(key,b); return b.count<=limit; }
setInterval(async()=>{const t=Date.now(); for(const [k,b] of rateBuckets) if(t-b.start>300_000) rateBuckets.delete(k); try{await pool.query('DELETE FROM sessions WHERE expires_at <= $1',[now()]);}catch(e){console.error('Session cleanup:',e.message);}}, 300_000).unref();
async function createSession(userId){ const token=crypto.randomBytes(32).toString('base64url'), exp=new Date(Date.now()+SESSION_DAYS*864e5).toISOString(); await pool.query('INSERT INTO sessions(user_id,token_hash,expires_at,created_at) VALUES($1,$2,$3,$4)',[userId,hashToken(token),exp,now()]); return {token,exp}; }
function publicUser(u){ return {id:u.id,name:u.name,email:u.email,role:u.role}; }

async function api(req,res,url){
  const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
  if((url.pathname==='/api/auth/login'||url.pathname==='/api/auth/signup') && !rateLimit(ip,10,60_000)) return json(res,429,{error:'Trop de tentatives. Réessayez dans une minute.'},{'Retry-After':'60'});
  if(req.method==='GET' && url.pathname==='/api/health') return json(res,200,{ok:true,service:'LoveConnect API',version:'13.0.0',database:'postgresql'});
  if(url.pathname==='/api/me' && req.method==='GET'){ const u=await userFromReq(req); return u?json(res,200,{authenticated:true,user:publicUser(u)}):json(res,200,{authenticated:false}); }
  if(url.pathname==='/api/auth/signup' && req.method==='POST'){
    if(!sameOrigin(req))return json(res,403,{error:'Origine refusée'}); const b=await body(req), name=String(b.name||'').trim(), email=String(b.email||'').trim().toLowerCase(), password=String(b.password||'');
    if(name.length<2||name.length>100||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<8)return json(res,400,{error:'Nom, e-mail ou mot de passe invalide.'});
    try{ const t=now(); const r=await pool.query('INSERT INTO users(name,email,password_hash,role,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6) RETURNING id',[name,email,passwordHash(password),'user',t,t]); const id=Number(r.rows[0].id); const s=await createSession(id); return json(res,201,{user:publicUser({id,name,email,role:'user'})},{'Set-Cookie':cookie(COOKIE,s.token,SESSION_DAYS*86400)}); }catch(e){ if(e.code==='23505')return json(res,409,{error:'Un compte existe déjà avec cet e-mail.'}); throw e; }
  }
  if(url.pathname==='/api/auth/login' && req.method==='POST'){
    if(!sameOrigin(req))return json(res,403,{error:'Origine refusée'}); const b=await body(req), email=String(b.email||'').trim().toLowerCase(), password=String(b.password||''); const {rows}=await pool.query('SELECT * FROM users WHERE email=$1',[email]); const u=rows[0]; if(!u||!passwordOk(password,u.password_hash))return json(res,401,{error:'Identifiants incorrects.'}); const s=await createSession(u.id); return json(res,200,{user:publicUser(u)},{'Set-Cookie':cookie(COOKIE,s.token,SESSION_DAYS*86400)});
  }
  if(url.pathname==='/api/auth/logout' && req.method==='POST'){
    if(!sameOrigin(req))return json(res,403,{error:'Origine refusée'}); const t=parseCookies(req)[COOKIE]; if(t)await pool.query('DELETE FROM sessions WHERE token_hash=$1',[hashToken(t)]); return json(res,200,{ok:true},{'Set-Cookie':cookie(COOKIE,'',0)});
  }
  if(url.pathname==='/api/posts' && req.method==='GET'){ const u=await userFromReq(req); if(!u)return json(res,401,{error:'Connexion requise'}); const {rows:posts}=await pool.query(`SELECT p.id,p.body,p.created_at,u.id user_id,u.name FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 50`); return json(res,200,{posts}); }
  if(url.pathname==='/api/posts' && req.method==='POST'){ const u=await userFromReq(req); if(!u)return json(res,401,{error:'Connexion requise'}); if(!sameOrigin(req))return json(res,403,{error:'Origine refusée'}); const b=await body(req), bodyText=String(b.body||'').trim(); if(!bodyText||bodyText.length>5000)return json(res,400,{error:'Publication invalide.'}); const t=now(); const r=await pool.query('INSERT INTO posts(user_id,body,created_at) VALUES($1,$2,$3) RETURNING id',[u.id,bodyText,t]); return json(res,201,{post:{id:Number(r.rows[0].id),body:bodyText,created_at:t,user_id:u.id,name:u.name}}); }
  if(url.pathname==='/api/admin/users' && req.method==='GET'){ const u=await userFromReq(req); if(!u||u.role!=='admin')return json(res,403,{error:'Accès administrateur requis'}); const {rows:users}=await pool.query('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 200'); return json(res,200,{users}); }
  return null;
}

const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8'};
const server=http.createServer(async(req,res)=>{ try{ const url=new URL(req.url,`http://${req.headers.host}`); if(url.pathname.startsWith('/api/')){const handled=await api(req,res,url); if(handled!==null)return;} let p=url.pathname==='/'?'/login.html':url.pathname; if(p.includes('..'))return json(res,400,{error:'Bad path'}); const file=path.join(__dirname,p); if(!existsSync(file))return json(res,404,{error:'Not found'}); const fileStat=await stat(file); if(!fileStat.isFile())return json(res,404,{error:'Not found'}); res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'strict-origin-when-cross-origin','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"}); res.end(await readFile(file)); }catch(e){ console.error(e); json(res,e.message==='PAYLOAD_TOO_LARGE'?413:500,{error:'Erreur serveur'}); }});
server.listen(PORT,HOST,()=>console.log(`LoveConnect V13: http://${HOST}:${PORT}`));
process.on('SIGTERM',async()=>{server.close(async()=>{await pool.end();process.exit(0);});});
process.on('SIGINT',async()=>{server.close(async()=>{await pool.end();process.exit(0);});});
