LoveConnect V14 — PostgreSQL

Cette version remplace SQLite par PostgreSQL pour les données persistantes.

Données actuellement gérées :
- utilisateurs
- sessions
- publications

Installation locale :
1. npm install
2. définir DATABASE_URL
3. définir SESSION_SECRET
4. npm start

La base et les tables sont créées automatiquement au démarrage.

Si tu as une ancienne base SQLite, utilise :
node scripts/migrate-sqlite-to-postgres.js

Pour le déploiement cloud, consulte DEPLOY.md.
