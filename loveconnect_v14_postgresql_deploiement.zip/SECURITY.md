# LoveConnect V12 — sécurité

Cette version remplace l'authentification `localStorage` de la démo par une authentification côté serveur.

- mots de passe hachés avec `scrypt` (API crypto native Node)
- sessions aléatoires stockées sous forme de hash en SQLite
- cookie de session `HttpOnly` + `SameSite=Lax` (+ `Secure` en production)
- contrôle serveur du rôle administrateur
- accès aux API membres refusé sans session valide
- expiration des sessions après 14 jours
- validation basique des entrées et contrôle d'origine pour les écritures

## Lancer

Node.js 22.5+ est requis car la base utilise `node:sqlite`.

```bash
npm start
```

Puis ouvrir `http://localhost:3000`.

## Créer un administrateur

Pour cette V12, les inscriptions publiques créent un rôle `user`. Pour une première installation, créer un compte utilisateur puis attribuer `admin` directement dans SQLite avec une commande d'administration contrôlée. Ne jamais ajouter une élévation de rôle dans le navigateur.

## Production

Avant ouverture publique : HTTPS, reverse proxy, rate limiting, vérification e-mail/téléphone, récupération de mot de passe, 2FA, rotation/révocation de sessions, CSP stricte, journalisation centralisée, sauvegardes chiffrées, stockage privé des médias et contrôles RGPD.
