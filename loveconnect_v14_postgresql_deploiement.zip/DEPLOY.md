# LoveConnect V13 — mise en ligne

## 1. Préparer le serveur
- Node.js 22.5+ est recommandé.
- En production, définissez `NODE_ENV=production`.
- Générez un secret long et aléatoire pour `SESSION_SECRET`.
- Utilisez HTTPS sur le domaine public.

## 2. Installation classique
```bash
npm start
```
Le serveur écoute sur `0.0.0.0:$PORT`.

## 3. Docker
```bash
docker build -t loveconnect .
docker run -d --name loveconnect -p 3000:3000 \
  -e NODE_ENV=production \
  -e SESSION_SECRET='VOTRE_SECRET_TRES_LONG' \
  -v loveconnect-data:/app/data \
  loveconnect
```

## 4. Domaine + HTTPS
Placez un reverse proxy HTTPS (Nginx, Caddy ou service cloud) devant LoveConnect et faites pointer le domaine vers le serveur. Le proxy doit transmettre `X-Forwarded-Proto: https`.

## 5. Base de données
SQLite est adaptée pour un démarrage simple. Le dossier `data/` doit être conservé dans un volume persistant. Pour une grosse charge, migrez ensuite vers PostgreSQL.

## 6. Important avant ouverture publique
- Remplacer SQLite par PostgreSQL si le trafic devient important.
- Ajouter e-mail/SMS de vérification et récupération de mot de passe.
- Configurer stockage objet pour photos/vidéos.
- Ajouter 2FA, modération et anti-fraude.
- Sauvegarder régulièrement `data/loveconnect.sqlite`.

## Anciennes données SQLite
Si tu as déjà un fichier `data/loveconnect.sqlite` contenant des données, définis `DATABASE_URL` puis exécute `node scripts/migrate-sqlite-to-postgres.js` avant de supprimer l'ancien fichier. Le script copie utilisateurs, sessions et publications et conserve leurs identifiants.
